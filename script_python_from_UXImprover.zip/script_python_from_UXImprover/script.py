import os
import time

FOLDER = "tasks here"  # Название папки с задачами

def solve_expression(expr):
    try:
        return eval(expr)
    except Exception as e:
        return f"Ошибка: {e}"

def main():
    print("🔥 huina.py запущен. Жду задачки в папке 'tasks here'...")
    already_solved = set()

    while True:
        try:
            files = os.listdir(FOLDER)
            for filename in files:
                if filename.endswith(".txt") and filename not in already_solved:
                    filepath = os.path.join(FOLDER, filename)
                    print(f"\n📄 Обработка файла: {filename}")
                    with open(filepath, "r", encoding="utf-8") as f:
                        lines = f.readlines()
                        for i, line in enumerate(lines, 1):
                            expr = line.strip()
                            if expr:
                                result = solve_expression(expr)
                                print(f"  [{i}] {expr} = {result}")
                    already_solved.add(filename)
            time.sleep(1)
        except KeyboardInterrupt:
            print("👋 Скрипт завершён.")
            break
        except Exception as e:
            print(f"⚠️ Ошибка: {e}")
            time.sleep(1)

if __name__ == "__main__":
    main()
